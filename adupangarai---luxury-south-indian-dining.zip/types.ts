
export enum Category {
  VEG_STARTERS = 'Veg Starters',
  NON_VEG_STARTERS = 'Non-Veg Starters',
  MAIN_COURSE_VEG = 'Main Course Veg',
  MAIN_COURSE_NON_VEG = 'Main Course Non-Veg',
  TANDOORI = 'Tandoori',
  DESSERTS = 'Desserts',
  BEVERAGES = 'Beverages'
}

export interface MenuItem {
  id: string;
  name: string;
  price: number;
  category: Category;
  description: string;
  isVeg: boolean;
  image: string;
}

export interface CartItem extends MenuItem {
  quantity: number;
}

export type OrderStatus = 'pending' | 'cooking' | 'delivered' | 'cancelled';

export interface Order {
  id: string;
  items: CartItem[];
  subtotal: number;
  gst: number;
  total: number;
  customer: {
    name: string;
    phone: string;
    address: string;
  };
  paymentMethod: 'cod' | 'upi' | 'card';
  transactionId?: string;
  status: OrderStatus;
  date: string;
}

export interface Reservation {
  id: string;
  name: string;
  email: string;
  phone: string;
  date: string;
  time: string;
  guests: string;
  status: 'pending' | 'confirmed' | 'cancelled';
}

export interface GalleryImage {
  id: string;
  url: string;
  title: string;
}
