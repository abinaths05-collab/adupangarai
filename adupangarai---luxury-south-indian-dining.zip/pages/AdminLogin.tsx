
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Lock, User } from 'lucide-react';

const AdminLogin: React.FC = () => {
  const [credentials, setCredentials] = useState({ username: '', password: '' });
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate auth
    if (credentials.username === 'admin' && credentials.password === 'admin') {
      navigate('/admin/dashboard');
    } else {
      alert('Invalid Credentials');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-100 px-4">
      <div className="max-w-md w-full bg-white p-10 border border-slate-200 shadow-2xl rounded-sm">
        <div className="text-center mb-10">
          <span className="text-2xl font-royal blue-text-gradient font-bold tracking-widest">ADUPANGARAI</span>
          <p className="text-slate-400 text-[10px] uppercase tracking-widest mt-2 font-bold">Management Portal</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div className="space-y-2">
            <label className="text-xs uppercase tracking-widest text-slate-500 font-bold">Username</label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-300" size={18} />
              <input 
                required 
                className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 py-3 pl-10 text-slate-800 outline-none rounded-sm" 
                placeholder="Staff ID" 
                onChange={(e) => setCredentials({...credentials, username: e.target.value})}
              />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-xs uppercase tracking-widest text-slate-500 font-bold">Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-300" size={18} />
              <input 
                required 
                type="password"
                className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 py-3 pl-10 text-slate-800 outline-none rounded-sm" 
                placeholder="••••••••" 
                onChange={(e) => setCredentials({...credentials, password: e.target.value})}
              />
            </div>
          </div>

          <button 
            type="submit" 
            className="w-full blue-gradient text-white font-bold py-3 rounded-sm uppercase tracking-widest text-sm hover:brightness-110 transition-all shadow-lg"
          >
            Authenticate
          </button>
        </form>
      </div>
    </div>
  );
};

export default AdminLogin;
