
import React, { useState } from 'react';
import { MENU_ITEMS } from '../constants';
import { Category } from '../types';
import { ShoppingBag, Plus, Minus, Search } from 'lucide-react';
import { useCart } from '../components/CartProvider';

const MenuPage: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<Category | 'All'>('All');
  const [isVegOnly, setIsVegOnly] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { addToCart, cart, updateQuantity } = useCart();

  const categories = ['All', ...Object.values(Category)];

  const filteredItems = MENU_ITEMS.filter(item => {
    const categoryMatch = activeCategory === 'All' || item.category === activeCategory;
    const vegMatch = !isVegOnly || item.isVeg;
    const searchMatch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
    return categoryMatch && vegMatch && searchMatch;
  });

  const getItemQuantity = (id: string) => {
    return cart.find(i => i.id === id)?.quantity || 0;
  };

  return (
    <div className="pt-24 min-h-screen bg-slate-50">
      {/* Menu Header with clear background image */}
      <div className="relative py-24 mb-8 border-b border-blue-900/20 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&q=80&w=2070" 
            alt="Food Background" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-blue-900/60 backdrop-blur-sm"></div>
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-royal text-white mb-4 font-bold tracking-widest drop-shadow-lg">The Royal Menu</h1>
          <p className="text-blue-100 max-w-2xl mx-auto font-semibold drop-shadow-md">Authentic flavors from the heart of South India, served in style.</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="flex flex-col lg:flex-row items-center justify-between mb-12 gap-6">
          <div className="flex flex-wrap justify-center lg:justify-start gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat as Category | 'All')}
                className={`px-4 py-2 text-[10px] uppercase tracking-widest transition-all duration-300 border ${
                  activeCategory === cat ? 'bg-blue-800 text-white border-blue-800 shadow-md' : 'text-blue-800 border-blue-800/20 bg-white hover:border-blue-800'
                } font-bold`}
              >
                {cat}
              </button>
            ))}
          </div>
          
          <div className="flex items-center space-x-4 w-full lg:w-auto">
            <div className="relative flex-grow lg:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
              <input 
                type="text"
                placeholder="Search dishes..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white border border-slate-200 py-2 pl-10 pr-4 text-sm text-slate-800 focus:border-blue-500 outline-none shadow-sm rounded-sm"
              />
            </div>
            <button
              onClick={() => setIsVegOnly(!isVegOnly)}
              className={`flex items-center space-x-2 px-4 py-2 border transition-all duration-300 rounded-sm ${
                isVegOnly ? 'bg-green-600 border-green-600 text-white' : 'bg-white border-slate-200 text-slate-600 hover:border-green-500'
              }`}
            >
              <div className={`w-2 h-2 rounded-full ${isVegOnly ? 'bg-white' : 'bg-green-500'}`}></div>
              <span className="text-[10px] uppercase tracking-widest font-bold">Veg Only</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredItems.map((item) => {
            const qty = getItemQuantity(item.id);
            return (
              <div key={item.id} className="group bg-white overflow-hidden border border-slate-200 hover:border-blue-300 hover:shadow-xl transition-all duration-500 rounded-sm">
                <div className="relative h-56 overflow-hidden">
                  <img src={item.image} alt={item.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                  <div className="absolute top-4 right-4">
                    <span className={`px-2 py-1 text-[10px] font-bold uppercase ${item.isVeg ? 'bg-green-600' : 'bg-red-600'} text-white shadow-md`}>
                      {item.isVeg ? 'Veg' : 'Non-Veg'}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-royal text-xl text-blue-900 group-hover:text-blue-600 transition-colors font-bold">{item.name}</h3>
                    <span className="text-blue-800 font-bold">₹{item.price}</span>
                  </div>
                  <p className="text-slate-500 text-sm mb-6 line-clamp-2 italic font-medium">{item.description}</p>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold">{item.category}</span>
                    {qty > 0 ? (
                      <div className="flex items-center space-x-3 bg-blue-800 text-white px-3 py-1 rounded-sm shadow-md">
                        <button onClick={() => updateQuantity(item.id, -1)}><Minus size={14} /></button>
                        <span className="font-bold text-sm">{qty}</span>
                        <button onClick={() => updateQuantity(item.id, 1)}><Plus size={14} /></button>
                      </div>
                    ) : (
                      <button 
                        onClick={() => addToCart(item)}
                        className="flex items-center space-x-2 text-blue-800 border-2 border-blue-800 px-4 py-2 hover:bg-blue-800 hover:text-white transition-all text-xs uppercase font-bold rounded-sm"
                      >
                        <ShoppingBag size={14} />
                        <span>Add to Cart</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default MenuPage;
