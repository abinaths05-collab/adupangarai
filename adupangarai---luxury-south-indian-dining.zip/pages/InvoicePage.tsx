
import React from 'react';
import { useLocation, useParams, useNavigate } from 'react-router-dom';
import { CheckCircle2, Printer, Home, ShieldCheck } from 'lucide-react';

const InvoicePage: React.FC = () => {
  const location = useLocation();
  const { orderId } = useParams();
  const navigate = useNavigate();
  const order = location.state?.order;

  if (!order) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <p className="text-blue-800 font-bold">Order data not found.</p>
      </div>
    );
  }

  const handlePrint = () => window.print();

  return (
    <div className="pt-32 pb-20 min-h-screen bg-slate-50 px-4 print:pt-0 print:bg-white">
      <div className="max-w-3xl mx-auto">
        
        {/* Success Header (Hidden in Print) */}
        <div className="text-center mb-12 print:hidden">
          <CheckCircle2 className="mx-auto text-green-500 w-16 h-16 mb-4" />
          <h1 className="text-4xl font-royal blue-text-gradient mb-2 font-bold tracking-widest">Order Confirmed!</h1>
          <p className="text-slate-500">Your royal feast is being prepared.</p>
          {order.transactionId && (
            <div className="mt-4 flex items-center justify-center gap-2 text-[10px] text-green-600 font-bold uppercase tracking-widest">
              <ShieldCheck size={14} />
              Payment Verified
            </div>
          )}
        </div>

        {/* Invoice Body */}
        <div className="bg-white text-slate-900 p-8 md:p-12 shadow-2xl border-t-8 border-blue-800 rounded-sm">
          <div className="flex flex-col md:flex-row justify-between items-start mb-12 gap-8">
            <div>
              <h2 className="text-3xl font-royal font-bold text-blue-900">ADUPANGARAI</h2>
              <p className="text-xs uppercase tracking-widest text-slate-400 mt-1 font-bold">The Royal Heritage</p>
              <div className="mt-6 text-sm text-slate-600">
                <p>123 Royal Heritage Road,</p>
                <p>Poes Garden, Chennai 600086</p>
                <p>+91 98765 43210</p>
              </div>
            </div>
            <div className="text-right">
              <h3 className="text-xl font-bold uppercase tracking-wider mb-2 text-blue-900">INVOICE</h3>
              <p className="text-sm font-mono text-slate-400">ID: {order.id}</p>
              <p className="text-sm text-slate-400 mt-1">Date: {order.date}</p>
              {order.transactionId && (
                <p className="text-[10px] font-mono text-blue-600 font-bold mt-1 uppercase tracking-wider">
                  TXN: {order.transactionId}
                </p>
              )}
            </div>
          </div>

          <div className="mb-12 grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h4 className="font-bold border-b border-slate-100 pb-2 mb-4 text-xs uppercase tracking-widest text-slate-400">Deliver To:</h4>
              <div className="text-sm">
                <p className="font-bold text-lg text-slate-800">{order.customer.name}</p>
                <p className="text-slate-600">{order.customer.phone}</p>
                <p className="max-w-xs text-slate-600">{order.customer.address}</p>
              </div>
            </div>
            <div className="md:text-right">
              <h4 className="font-bold border-b border-slate-100 pb-2 mb-4 text-xs uppercase tracking-widest text-slate-400">Payment Status:</h4>
              <p className="text-sm font-bold text-slate-800 uppercase tracking-widest">
                {order.transactionId ? 'Paid Online' : 'Cash on Delivery'}
              </p>
              <p className="text-xs text-slate-500 mt-1">Method: {order.paymentMethod.toUpperCase()}</p>
            </div>
          </div>

          <table className="w-full text-left mb-8">
            <thead>
              <tr className="border-b-2 border-blue-900 text-xs uppercase tracking-widest text-slate-400">
                <th className="py-4">Item</th>
                <th className="py-4 text-center">Qty</th>
                <th className="py-4 text-right">Price</th>
                <th className="py-4 text-right">Total</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              {order.items.map((item: any) => (
                <tr key={item.id} className="border-b border-slate-50">
                  <td className="py-4 font-bold text-slate-800">{item.name}</td>
                  <td className="py-4 text-center text-slate-600">{item.quantity}</td>
                  <td className="py-4 text-right text-slate-600">₹{item.price}</td>
                  <td className="py-4 text-right font-bold text-slate-800">₹{item.price * item.quantity}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="flex justify-end">
            <div className="w-full md:w-64 space-y-3">
              <div className="flex justify-between text-sm text-slate-400 font-bold">
                <span>Subtotal</span>
                <span>₹{order.subtotal}</span>
              </div>
              <div className="flex justify-between text-sm text-slate-400 font-bold">
                <span>GST (5%)</span>
                <span>₹{order.gst.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-xl font-bold border-t-2 border-slate-900 pt-3 text-blue-900">
                <span>Total</span>
                <span>₹{order.total.toFixed(2)}</span>
              </div>
            </div>
          </div>

          <div className="mt-16 text-center border-t border-slate-50 pt-8">
            <p className="text-slate-400 text-xs italic">Thank you for dining with ADUPANGARAI. We hope you enjoy the taste of tradition.</p>
          </div>
        </div>

        {/* Actions (Hidden in Print) */}
        <div className="mt-12 flex flex-wrap justify-center gap-6 print:hidden">
          <button onClick={handlePrint} className="flex items-center space-x-2 border-2 border-blue-800 text-blue-800 px-8 py-3 hover:bg-blue-800 hover:text-white transition-all font-bold uppercase tracking-widest text-sm rounded-sm">
            <Printer size={18} />
            <span>Print Bill</span>
          </button>
          <button onClick={() => navigate('/')} className="flex items-center space-x-2 blue-gradient px-8 py-3 text-white font-bold uppercase tracking-widest text-sm rounded-sm shadow-lg">
            <Home size={18} />
            <span>Back to Home</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default InvoicePage;
