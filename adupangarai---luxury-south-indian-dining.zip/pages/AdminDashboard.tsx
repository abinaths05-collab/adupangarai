
import React, { useState, useEffect } from 'react';
import { MENU_ITEMS } from '../constants';
import { Plus, Edit2, Trash2, Calendar, LayoutDashboard, Utensils, LogOut, Package, TrendingUp, IndianRupee } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Order, OrderStatus } from '../types';

const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'orders' | 'reservations' | 'menu'>('orders');
  const [orders, setOrders] = useState<Order[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    const savedOrders = JSON.parse(localStorage.getItem('orders') || '[]');
    setOrders(savedOrders);
  }, []);

  const updateOrderStatus = (orderId: string, newStatus: OrderStatus) => {
    const updated = orders.map(o => o.id === orderId ? { ...o, status: newStatus } : o);
    setOrders(updated);
    localStorage.setItem('orders', JSON.stringify(updated));
  };

  const deleteOrder = (orderId: string) => {
    const updated = orders.filter(o => o.id !== orderId);
    setOrders(updated);
    localStorage.setItem('orders', JSON.stringify(updated));
  };

  const totalRevenue = orders.reduce((sum, o) => sum + o.total, 0);

  const getStatusColor = (status: OrderStatus) => {
    switch(status) {
      case 'pending': 
        return 'bg-amber-50 text-amber-700 border-amber-200 ring-1 ring-amber-100'; // Warm Amber for waiting
      case 'cooking': 
        return 'bg-violet-50 text-violet-700 border-violet-200 ring-1 ring-violet-100'; // Unique Violet for preparation
      case 'delivered': 
        return 'bg-emerald-50 text-emerald-700 border-emerald-200 ring-1 ring-emerald-100'; // Fresh Green for success
      case 'cancelled': 
        return 'bg-rose-50 text-rose-700 border-rose-200 ring-1 ring-rose-100'; // Soft Red for cancellation
      default: 
        return 'bg-slate-50 text-slate-700 border-slate-200 ring-1 ring-slate-100';
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar */}
      <div className="w-64 bg-[#0F172A] border-r border-blue-900/20 hidden md:flex flex-col shadow-2xl">
        <div className="p-8">
          <span className="text-xl font-royal text-white font-bold tracking-widest">ADUPANGARAI</span>
          <p className="text-[10px] text-blue-400 uppercase tracking-widest mt-1 font-bold">Admin Panel</p>
        </div>
        <nav className="mt-8 flex-grow">
          {[
            { id: 'orders', icon: <Package size={20} />, label: 'Live Orders' },
            { id: 'reservations', icon: <Calendar size={20} />, label: 'Table Bookings' },
            { id: 'menu', icon: <Utensils size={20} />, label: 'Menu Items' }
          ].map(tab => (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`w-full flex items-center space-x-4 px-8 py-4 text-xs uppercase tracking-widest transition-colors ${activeTab === tab.id ? 'bg-blue-800 text-white border-r-4 border-blue-400' : 'text-slate-400 hover:bg-slate-800'}`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </nav>
        <button onClick={() => navigate('/')} className="w-full flex items-center space-x-4 px-8 py-8 text-xs uppercase tracking-widest text-slate-500 hover:text-white border-t border-slate-800">
          <LogOut size={20} />
          <span>Exit Dashboard</span>
        </button>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8 overflow-y-auto">
        
        {/* Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 border-l-4 border-blue-800 shadow-sm rounded-sm">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-xs uppercase text-slate-400 tracking-widest mb-1 font-bold">Total Revenue</p>
                <h3 className="text-2xl font-royal text-blue-900 font-bold">₹{totalRevenue.toFixed(2)}</h3>
              </div>
              <IndianRupee className="text-blue-800 opacity-20" size={32} />
            </div>
          </div>
          <div className="bg-white p-6 border-l-4 border-violet-500 shadow-sm rounded-sm">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-xs uppercase text-slate-400 tracking-widest mb-1 font-bold">Live Orders</p>
                <h3 className="text-2xl font-royal text-blue-900 font-bold">{orders.filter(o => o.status !== 'delivered' && o.status !== 'cancelled').length}</h3>
              </div>
              <Package className="text-violet-500 opacity-20" size={32} />
            </div>
          </div>
          <div className="bg-white p-6 border-l-4 border-emerald-500 shadow-sm rounded-sm">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-xs uppercase text-slate-400 tracking-widest mb-1 font-bold">Completed</p>
                <h3 className="text-2xl font-royal text-blue-900 font-bold">{orders.filter(o => o.status === 'delivered').length}</h3>
              </div>
              <TrendingUp className="text-emerald-500 opacity-20" size={32} />
            </div>
          </div>
        </div>

        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-royal text-blue-900 uppercase tracking-widest font-bold">{activeTab} Management</h1>
          {activeTab === 'menu' && (
            <button className="blue-gradient text-white px-6 py-2 rounded-sm text-xs font-bold uppercase tracking-wider flex items-center shadow-md">
              <Plus size={18} className="mr-2" /> Add Item
            </button>
          )}
        </div>

        {activeTab === 'orders' ? (
          <div className="space-y-4">
            {orders.length === 0 ? (
              <div className="bg-white border border-slate-200 rounded-sm p-20 text-center">
                <Package className="mx-auto text-slate-200 w-16 h-16 mb-4" />
                <p className="text-slate-400 italic">No orders recorded in the royal scrolls yet.</p>
              </div>
            ) : orders.map((order) => (
              <div key={order.id} className="bg-white p-6 flex flex-col md:flex-row justify-between gap-6 border border-slate-200 shadow-sm hover:shadow-md transition-all rounded-sm border-l-4 border-l-blue-100">
                <div>
                  <div className="flex items-center space-x-3 mb-2">
                    <span className="text-sm font-mono text-blue-800 font-bold">{order.id}</span>
                    <span className={`px-3 py-1 border rounded-full text-[10px] uppercase font-bold tracking-widest ${getStatusColor(order.status)}`}>
                      {order.status}
                    </span>
                  </div>
                  <h4 className="text-slate-800 font-bold text-lg">{order.customer.name} • {order.items.length} Items</h4>
                  <p className="text-xs text-slate-500 mt-1 font-medium">{order.customer.address}</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right mr-4">
                    <p className="text-blue-900 font-bold text-lg">₹{order.total.toFixed(2)}</p>
                    <p className="text-[10px] text-slate-400 uppercase font-bold tracking-widest">{order.paymentMethod}</p>
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] uppercase text-slate-400 font-bold">Update Status</label>
                    <select 
                      value={order.status}
                      onChange={(e) => updateOrderStatus(order.id, e.target.value as OrderStatus)}
                      className="bg-slate-50 border border-slate-200 text-xs text-slate-800 p-2 outline-none focus:border-blue-500 font-bold rounded-sm shadow-sm"
                    >
                      <option value="pending">Pending</option>
                      <option value="cooking">Cooking</option>
                      <option value="delivered">Delivered</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </div>
                  <button onClick={() => deleteOrder(order.id)} className="text-slate-300 hover:text-red-500 transition-colors p-2 hover:bg-red-50 rounded-full" title="Remove Order">
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white p-20 text-center border border-slate-200 text-slate-400 font-royal text-xl rounded-sm">
            <LayoutDashboard className="mx-auto text-slate-200 w-16 h-16 mb-4" />
            <p>Content for {activeTab} goes here.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
