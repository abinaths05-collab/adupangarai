
import React from 'react';
import { GALLERY_IMAGES } from '../constants';

const GalleryPage: React.FC = () => {
  return (
    <div className="pt-24 min-h-screen bg-slate-50">
      <div className="bg-[#0F172A] py-16 border-b border-blue-900/20">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-royal text-white mb-4 font-bold tracking-widest">Glimpses of Grandeur</h1>
          <p className="text-blue-300 max-w-2xl mx-auto font-light">Take a visual tour through the royal halls and exquisite creations of ADUPANGARAI.</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {GALLERY_IMAGES.map((img) => (
            <div key={img.id} className="group relative h-80 overflow-hidden cursor-pointer shadow-lg rounded-sm border border-slate-200">
              <img 
                src={img.url} 
                alt={img.title} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-125"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-blue-900/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-end p-8">
                <div>
                  <h3 className="text-white font-royal text-2xl mb-1 translate-y-4 group-hover:translate-y-0 transition-transform duration-500 font-bold">{img.title}</h3>
                  <div className="w-12 h-0.5 bg-blue-400 opacity-0 group-hover:opacity-100 transition-opacity delay-200"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default GalleryPage;
