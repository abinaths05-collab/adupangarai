
import React, { useState } from 'react';
import { Calendar, Clock, Users, Phone, Mail, User, CheckCircle2 } from 'lucide-react';

const ReservationPage: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    date: '',
    time: '',
    guests: '2'
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 1500);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  if (submitted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 px-4">
        <div className="max-w-md w-full bg-white p-12 text-center border border-slate-200 shadow-2xl">
          <CheckCircle2 className="mx-auto text-green-500 w-20 h-20 mb-6 animate-pulse" />
          <h2 className="text-3xl font-royal text-blue-900 mb-4 font-bold">Reservation Successful</h2>
          <p className="text-slate-500 mb-8 font-light">Dear {formData.name}, your table for {formData.guests} has been reserved for {formData.date} at {formData.time}. A confirmation email has been sent.</p>
          <button 
            onClick={() => setSubmitted(false)}
            className="blue-gradient text-white font-bold py-3 px-8 rounded-sm uppercase tracking-widest text-sm shadow-md"
          >
            Make Another Booking
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-24 min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        {/* Text Side */}
        <div>
          <h4 className="text-blue-600 uppercase tracking-[0.3em] mb-4 font-bold">Dining Experience</h4>
          <h1 className="text-4xl md:text-6xl font-royal text-blue-900 mb-8 font-bold">Reserve Your <span className="blue-text-gradient">Royal Table</span></h1>
          <p className="text-slate-600 text-lg mb-8 leading-relaxed font-light">
            Whether it's a family gathering, a business meeting, or a romantic evening, ADUPANGARAI offers the perfect setting for your memorable moments.
          </p>
          <div className="space-y-6">
            <div className="flex items-center space-x-4 p-4 bg-white border-l-4 border-blue-600 shadow-sm">
              <div className="text-blue-600"><Users size={24} /></div>
              <div>
                <h5 className="text-blue-900 font-bold">Group Dining</h5>
                <p className="text-slate-500 text-sm">We accommodate groups up to 25 people.</p>
              </div>
            </div>
            <div className="flex items-center space-x-4 p-4 bg-white border-l-4 border-blue-600 shadow-sm">
              <div className="text-blue-600"><Clock size={24} /></div>
              <div>
                <h5 className="text-blue-900 font-bold">Punctuality</h5>
                <p className="text-slate-500 text-sm">Tables are held for 15 minutes past reservation time.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Form Side */}
        <div className="bg-white p-8 md:p-12 border border-slate-200 shadow-2xl relative rounded-sm">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest text-slate-500 ml-1 font-bold">Full Name</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-300" size={18} />
                  <input 
                    required 
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full bg-slate-50 border border-slate-200 focus:border-blue-600 py-3 pl-10 pr-4 text-slate-800 outline-none transition-colors rounded-sm" 
                    placeholder="Arun Kumar" 
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest text-slate-500 ml-1 font-bold">Phone Number</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-300" size={18} />
                  <input 
                    required 
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full bg-slate-50 border border-slate-200 focus:border-blue-600 py-3 pl-10 pr-4 text-slate-800 outline-none transition-colors rounded-sm" 
                    placeholder="+91 98765 43210" 
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs uppercase tracking-widest text-slate-500 ml-1 font-bold">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-300" size={18} />
                <input 
                  required 
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-600 py-3 pl-10 pr-4 text-slate-800 outline-none transition-colors rounded-sm" 
                  placeholder="arun@example.com" 
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest text-slate-500 ml-1 font-bold">Guests</label>
                <div className="relative">
                  <Users className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-300" size={18} />
                  <select 
                    name="guests"
                    value={formData.guests}
                    onChange={handleChange}
                    className="w-full bg-slate-50 border border-slate-200 focus:border-blue-600 py-3 pl-10 pr-4 text-slate-800 outline-none transition-colors appearance-none rounded-sm font-bold"
                  >
                    {[1, 2, 3, 4, 5, 6, 7, 8].map(n => <option key={n} value={n}>{n} Guests</option>)}
                    <option value="9+">9+ Guests</option>
                  </select>
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest text-slate-500 ml-1 font-bold">Date</label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-300" size={18} />
                  <input 
                    required 
                    type="date"
                    name="date"
                    value={formData.date}
                    onChange={handleChange}
                    className="w-full bg-slate-50 border border-slate-200 focus:border-blue-600 py-3 pl-10 pr-4 text-slate-800 outline-none transition-colors rounded-sm" 
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest text-slate-500 ml-1 font-bold">Time</label>
                <div className="relative">
                  <Clock className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-300" size={18} />
                  <select 
                    required 
                    name="time"
                    value={formData.time}
                    onChange={handleChange}
                    className="w-full bg-slate-50 border border-slate-200 focus:border-blue-600 py-3 pl-10 pr-4 text-slate-800 outline-none transition-colors appearance-none rounded-sm font-bold"
                  >
                    <option value="">Select Time</option>
                    <option value="12:00 PM">12:00 PM</option>
                    <option value="01:00 PM">01:00 PM</option>
                    <option value="02:00 PM">02:00 PM</option>
                    <option value="07:00 PM">07:00 PM</option>
                    <option value="08:00 PM">08:00 PM</option>
                    <option value="09:00 PM">09:00 PM</option>
                  </select>
                </div>
              </div>
            </div>

            <button 
              type="submit" 
              disabled={loading}
              className={`w-full blue-gradient text-white font-bold py-4 rounded-sm uppercase tracking-widest text-sm hover:brightness-110 transition-all shadow-xl ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {loading ? 'Processing...' : 'Confirm Reservation'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ReservationPage;
