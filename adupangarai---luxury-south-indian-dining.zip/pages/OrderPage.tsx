
import React, { useState } from 'react';
import { useCart } from '../components/CartProvider';
import { Trash2, Plus, Minus, CreditCard, Wallet, Truck, ShoppingBag, ShieldCheck } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import PaymentModal from '../components/PaymentModal';

const OrderPage: React.FC = () => {
  const { cart, updateQuantity, removeFromCart, cartTotal, placeOrder } = useCart();
  const navigate = useNavigate();
  const [showPayment, setShowPayment] = useState(false);
  const [customer, setCustomer] = useState({ name: '', phone: '', address: '' });
  const [paymentType, setPaymentType] = useState<'cod' | 'online'>('online');

  const gst = cartTotal * 0.05;
  const grandTotal = cartTotal + gst;

  const handleSubmitRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;

    if (paymentType === 'online') {
      setShowPayment(true);
    } else {
      // Direct placement for COD
      const order = placeOrder(customer, 'cod');
      navigate(`/invoice/${order.id}`, { state: { order } });
    }
  };

  const handlePaymentSuccess = (txId: string) => {
    const order = placeOrder(customer, 'card', txId);
    setShowPayment(false);
    navigate(`/invoice/${order.id}`, { state: { order } });
  };

  if (cart.length === 0) {
    return (
      <div className="pt-32 min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
        <div className="bg-white p-12 text-center max-w-md w-full border border-slate-200 shadow-xl">
          <ShoppingBag className="mx-auto text-blue-200 w-16 h-16 mb-6" />
          <h2 className="text-3xl font-royal text-blue-900 mb-4 font-bold">Your Cart is Empty</h2>
          <p className="text-slate-500 mb-8">Bring home the flavors of royalty today.</p>
          <button onClick={() => navigate('/menu')} className="blue-gradient w-full py-4 text-white font-bold uppercase tracking-widest shadow-lg">Browse Menu</button>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-24 min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* Cart Items */}
          <div className="lg:col-span-7 space-y-6">
            <h2 className="text-3xl font-royal text-blue-900 mb-8 border-b-2 border-blue-100 pb-4 font-bold">Your Selection</h2>
            {cart.map((item) => (
              <div key={item.id} className="bg-white p-4 flex items-center gap-4 border border-slate-200 shadow-sm rounded-sm">
                <img src={item.image} alt={item.name} className="w-24 h-24 object-cover rounded-sm border border-slate-100" />
                <div className="flex-grow">
                  <h3 className="text-blue-900 font-royal text-lg font-bold">{item.name}</h3>
                  <p className="text-blue-700 font-bold">₹{item.price}</p>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-3 bg-slate-50 border border-slate-200 px-3 py-1 text-slate-800">
                    <button onClick={() => updateQuantity(item.id, -1)} className="hover:text-blue-600"><Minus size={14} /></button>
                    <span className="w-4 text-center text-sm font-bold">{item.quantity}</span>
                    <button onClick={() => updateQuantity(item.id, 1)} className="hover:text-blue-600"><Plus size={14} /></button>
                  </div>
                  <button onClick={() => removeFromCart(item.id)} className="text-slate-300 hover:text-red-500 transition-colors">
                    <Trash2 size={20} />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Checkout Form */}
          <div className="lg:col-span-5">
            <div className="bg-white p-8 sticky top-24 border border-slate-200 shadow-xl rounded-sm">
              <h3 className="text-2xl font-royal text-blue-900 mb-6 font-bold">Delivery Details</h3>
              <form onSubmit={handleSubmitRequest} className="space-y-6">
                <div className="space-y-4">
                  <input 
                    required 
                    placeholder="Receiver's Name" 
                    className="w-full bg-slate-50 border border-slate-200 p-3 text-slate-800 outline-none focus:border-blue-500 rounded-sm"
                    value={customer.name}
                    onChange={(e) => setCustomer({...customer, name: e.target.value})}
                  />
                  <input 
                    required 
                    placeholder="Phone Number" 
                    className="w-full bg-slate-50 border border-slate-200 p-3 text-slate-800 outline-none focus:border-blue-500 rounded-sm"
                    value={customer.phone}
                    onChange={(e) => setCustomer({...customer, phone: e.target.value})}
                  />
                  <textarea 
                    required 
                    placeholder="Complete Delivery Address" 
                    className="w-full bg-slate-50 border border-slate-200 p-3 text-slate-800 outline-none focus:border-blue-500 h-24 rounded-sm"
                    value={customer.address}
                    onChange={(e) => setCustomer({...customer, address: e.target.value})}
                  />
                </div>

                <div className="space-y-4">
                  <label className="text-xs uppercase tracking-widest text-blue-800 font-bold">Select Payment Flow</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setPaymentType('online')}
                      className={`flex flex-col items-center justify-center p-3 border-2 transition-all rounded-sm ${paymentType === 'online' ? 'bg-blue-800 text-white border-blue-800' : 'border-slate-200 text-slate-400 hover:border-slate-400'}`}
                    >
                      <CreditCard size={18} />
                      <span className="text-[10px] mt-1 font-bold">Online Payment</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setPaymentType('cod')}
                      className={`flex flex-col items-center justify-center p-3 border-2 transition-all rounded-sm ${paymentType === 'cod' ? 'bg-blue-800 text-white border-blue-800' : 'border-slate-200 text-slate-400 hover:border-slate-400'}`}
                    >
                      <Truck size={18} />
                      <span className="text-[10px] mt-1 font-bold">Pay on Delivery</span>
                    </button>
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-100 space-y-2">
                  <div className="flex justify-between text-slate-500 text-sm">
                    <span>Subtotal</span>
                    <span>₹{cartTotal}</span>
                  </div>
                  <div className="flex justify-between text-slate-500 text-sm">
                    <span>GST (5%)</span>
                    <span>₹{gst.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-blue-900 font-bold text-xl pt-2">
                    <span>Grand Total</span>
                    <span className="text-blue-600">₹{grandTotal.toFixed(2)}</span>
                  </div>
                </div>

                <button 
                  type="submit" 
                  className="w-full blue-gradient py-4 text-white font-bold uppercase tracking-widest hover:brightness-110 transition-all shadow-lg rounded-sm"
                >
                  {paymentType === 'online' ? 'Proceed to Pay' : 'Confirm Order'}
                </button>
                
                {paymentType === 'online' && (
                  <div className="flex items-center justify-center gap-2 text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-4">
                    <ShieldCheck size={14} className="text-green-500" />
                    Encrypted Razorpay Payment
                  </div>
                )}
              </form>
            </div>
          </div>

        </div>
      </div>

      {showPayment && (
        <PaymentModal 
          amount={grandTotal}
          customerName={customer.name}
          onSuccess={handlePaymentSuccess}
          onCancel={() => setShowPayment(false)}
        />
      )}
    </div>
  );
};

export default OrderPage;
