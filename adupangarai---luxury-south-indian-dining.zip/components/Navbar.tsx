
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ShoppingBag } from 'lucide-react';
import { useCart } from './CartProvider';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const { cart } = useCart();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Menu', path: '/menu' },
    { name: 'Order Online', path: '/order' },
    { name: 'Gallery', path: '/gallery' },
    { name: 'Reservations', path: '/reservation' },
  ];

  const isActive = (path: string) => location.pathname === path;
  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${scrolled ? 'glass-blue py-2 shadow-lg border-b border-blue-100' : 'bg-transparent py-4'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex-shrink-0 flex flex-col items-center">
            <span className={`text-2xl md:text-3xl font-royal ${scrolled ? 'blue-text-gradient' : 'text-white'} tracking-widest font-bold`}>ADUPANGARAI</span>
            <span className={`text-[10px] uppercase tracking-[0.3em] ${scrolled ? 'text-blue-900' : 'text-blue-100'} -mt-1 font-semibold`}>The Royal Heritage</span>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden lg:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className={`text-[11px] font-bold uppercase tracking-widest transition-colors duration-200 ${isActive(link.path) ? (scrolled ? 'text-blue-800' : 'text-white border-b-2 border-white') : (scrolled ? 'text-slate-600 hover:text-blue-600' : 'text-white/80 hover:text-white')}`}
              >
                {link.name}
              </Link>
            ))}
            <Link to="/order" className={`relative ${scrolled ? 'text-blue-800' : 'text-white'} hover:scale-110 transition-transform`}>
              <ShoppingBag size={22} />
              {cartItemCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-blue-600 text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold shadow-md">
                  {cartItemCount}
                </span>
              )}
            </Link>
            <Link
              to="/reservation"
              className="blue-gradient px-6 py-2 rounded-sm text-white font-bold text-xs uppercase tracking-widest hover:brightness-110 transition-all shadow-md"
            >
              Book Table
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden flex items-center space-x-4">
            <Link to="/order" className={`relative ${scrolled ? 'text-blue-800' : 'text-white'}`}>
              <ShoppingBag size={22} />
              {cartItemCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-blue-600 text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                  {cartItemCount}
                </span>
              )}
            </Link>
            <button onClick={() => setIsOpen(!isOpen)} className={`${scrolled ? 'text-blue-800' : 'text-white'} focus:outline-none`}>
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="lg:hidden glass-blue absolute top-full left-0 w-full animate-fadeIn border-b border-blue-100">
          <div className="px-4 pt-2 pb-6 space-y-4 text-center">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                onClick={() => setIsOpen(false)}
                className="block text-sm uppercase tracking-widest text-slate-800 hover:text-blue-600 transition-colors py-2 font-semibold"
              >
                {link.name}
              </Link>
            ))}
            <Link
              to="/reservation"
              onClick={() => setIsOpen(false)}
              className="inline-block blue-gradient px-8 py-3 rounded-sm text-white font-bold text-xs uppercase tracking-wider w-full"
            >
              Book Table
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
