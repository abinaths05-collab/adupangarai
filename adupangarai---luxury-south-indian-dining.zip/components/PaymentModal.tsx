
import React, { useState, useEffect } from 'react';
import { X, CreditCard, Smartphone, Landmark, CheckCircle, ShieldCheck, Loader2 } from 'lucide-react';

interface PaymentModalProps {
  amount: number;
  customerName: string;
  onSuccess: (transactionId: string) => void;
  onCancel: () => void;
}

const PaymentModal: React.FC<PaymentModalProps> = ({ amount, customerName, onSuccess, onCancel }) => {
  const [step, setStep] = useState<'methods' | 'processing' | 'success'>('methods');
  const [selectedMethod, setSelectedMethod] = useState<string | null>(null);

  const handlePay = (method: string) => {
    setSelectedMethod(method);
    setStep('processing');
    
    // Simulate payment processing time
    setTimeout(() => {
      setStep('success');
      setTimeout(() => {
        const txId = `pay_${Math.random().toString(36).substr(2, 14).toUpperCase()}`;
        onSuccess(txId);
      }, 1500);
    }, 2500);
  };

  const methods = [
    { id: 'upi', label: 'UPI (GPay, PhonePe, etc.)', icon: <Smartphone className="text-blue-500" /> },
    { id: 'card', label: 'Debit / Credit Card', icon: <CreditCard className="text-orange-500" /> },
    { id: 'net', label: 'Netbanking', icon: <Landmark className="text-indigo-500" /> },
  ];

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white w-full max-w-md shadow-2xl relative overflow-hidden rounded-sm">
        
        {/* Header */}
        <div className="bg-blue-900 p-6 text-white flex justify-between items-center">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-royal text-xl tracking-widest font-bold">ADUPANGARAI</span>
            </div>
            <p className="text-[10px] text-blue-200 uppercase tracking-widest font-bold">Secure Checkout</p>
          </div>
          <button onClick={onCancel} className="text-white/60 hover:text-white transition-colors">
            <X size={24} />
          </button>
        </div>

        <div className="p-8">
          {step === 'methods' && (
            <div className="animate-slideUp">
              <div className="flex justify-between items-center mb-8 pb-4 border-b border-slate-100">
                <span className="text-slate-500 text-sm font-medium">Payable Amount</span>
                <span className="text-2xl font-bold text-blue-900">₹{amount.toFixed(2)}</span>
              </div>

              <h3 className="text-xs uppercase tracking-[0.2em] text-slate-400 font-bold mb-4">Payment Methods</h3>
              <div className="space-y-3">
                {methods.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => handlePay(m.id)}
                    className="w-full flex items-center justify-between p-4 border border-slate-200 hover:border-blue-500 hover:bg-blue-50/30 transition-all group"
                  >
                    <div className="flex items-center gap-4">
                      {m.icon}
                      <span className="text-sm font-bold text-slate-700">{m.label}</span>
                    </div>
                    <div className="w-4 h-4 rounded-full border border-slate-300 group-hover:border-blue-500"></div>
                  </button>
                ))}
              </div>

              <div className="mt-8 flex items-center justify-center gap-2 text-[10px] text-slate-400 font-bold uppercase tracking-widest">
                <ShieldCheck size={14} className="text-green-500" />
                Secured by Razorpay
              </div>
            </div>
          )}

          {step === 'processing' && (
            <div className="text-center py-10 animate-fadeIn">
              <Loader2 className="w-16 h-16 text-blue-600 animate-spin mx-auto mb-6" />
              <h3 className="text-xl font-bold text-blue-900 mb-2">Processing Payment</h3>
              <p className="text-slate-500 text-sm">Please do not refresh or close this window.</p>
              <div className="mt-8 text-[10px] text-blue-400 font-bold uppercase tracking-widest">
                Contacting Bank Servers...
              </div>
            </div>
          )}

          {step === 'success' && (
            <div className="text-center py-10 animate-scaleIn">
              <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle size={40} />
              </div>
              <h3 className="text-2xl font-bold text-blue-900 mb-2">Payment Successful</h3>
              <p className="text-slate-500 text-sm">Your royal feast is now being prepared.</p>
            </div>
          )}
        </div>

        {/* Brand Bar */}
        <div className="bg-slate-50 p-3 text-center border-t border-slate-100">
           <p className="text-[10px] text-slate-400 font-medium">RAZORPAY SECURE • PCI-DSS COMPLIANT</p>
        </div>
      </div>
    </div>
  );
};

export default PaymentModal;
