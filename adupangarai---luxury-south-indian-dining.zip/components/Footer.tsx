
import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Instagram, Facebook, Twitter } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#0F172A] border-t border-blue-900/30 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          {/* Logo & About */}
          <div className="col-span-1 md:col-span-1">
            <Link to="/" className="inline-block mb-6">
              <span className="text-3xl font-royal text-white font-bold">ADUPANGARAI</span>
            </Link>
            <p className="text-slate-400 text-sm leading-relaxed mb-6">
              Preserving the sacred traditions of South Indian culinary arts. Every dish is a testament to heritage, royalty, and authentic flavors.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-slate-400 hover:text-blue-400 transition-colors"><Instagram size={20} /></a>
              <a href="#" className="text-slate-400 hover:text-blue-400 transition-colors"><Facebook size={20} /></a>
              <a href="#" className="text-slate-400 hover:text-blue-400 transition-colors"><Twitter size={20} /></a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-royal text-blue-400 text-lg mb-6 tracking-wider font-bold">Quick Links</h4>
            <ul className="space-y-3">
              <li><Link to="/menu" className="text-slate-400 hover:text-white transition-colors text-sm">Our Menu</Link></li>
              <li><Link to="/reservation" className="text-slate-400 hover:text-white transition-colors text-sm">Reservations</Link></li>
              <li><Link to="/gallery" className="text-slate-400 hover:text-white transition-colors text-sm">Gallery</Link></li>
              <li><Link to="/about" className="text-slate-400 hover:text-white transition-colors text-sm">About Heritage</Link></li>
              <li><Link to="/admin" className="text-slate-400 hover:text-white transition-colors text-sm">Staff Login</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-royal text-blue-400 text-lg mb-6 tracking-wider font-bold">Reach Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start space-x-3">
                <MapPin className="text-blue-500 flex-shrink-0 mt-1" size={18} />
                <span className="text-slate-400 text-sm">123 Royal Heritage Road,<br />Poes Garden, Chennai 600086</span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone className="text-blue-500 flex-shrink-0" size={18} />
                <span className="text-slate-400 text-sm">+91 98765 43210</span>
              </li>
              <li className="flex items-center space-x-3">
                <Mail className="text-blue-500 flex-shrink-0" size={18} />
                <span className="text-slate-400 text-sm">royalty@adupangarai.com</span>
              </li>
            </ul>
          </div>

          {/* Hours */}
          <div>
            <h4 className="font-royal text-blue-400 text-lg mb-6 tracking-wider font-bold">Dining Hours</h4>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-slate-400">Lunch</span>
                <span className="text-white">12:00 PM - 3:30 PM</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-400">Dinner</span>
                <span className="text-white">7:00 PM - 11:00 PM</span>
              </div>
              <div className="mt-6 p-4 border border-blue-500/20 bg-blue-900/50">
                <p className="text-blue-400 text-xs uppercase tracking-widest text-center font-bold">Open All Days</p>
              </div>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center text-xs text-slate-500 gap-4">
          <p>&copy; {new Date().getFullYear()} ADUPANGARAI. All Rights Reserved.</p>
          <div className="flex space-x-6">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
