
import React, { useEffect } from 'react';
import { HashRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import MenuPage from './pages/MenuPage';
import ReservationPage from './pages/ReservationPage';
import GalleryPage from './pages/GalleryPage';
import AdminLogin from './pages/AdminLogin';
import AdminDashboard from './pages/AdminDashboard';
import OrderPage from './pages/OrderPage';
import InvoicePage from './pages/InvoicePage';
import { CartProvider } from './components/CartProvider';

const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const App: React.FC = () => {
  return (
    <CartProvider>
      <Router>
        <ScrollToTop />
        <div className="flex flex-col min-h-screen">
          <Routes>
            <Route path="/admin" element={<AdminLogin />} />
            <Route path="/admin/dashboard" element={<AdminDashboard />} />
            <Route path="/invoice/:orderId" element={<InvoicePage />} />
            
            <Route 
              path="/*" 
              element={
                <>
                  <Navbar />
                  <main className="flex-grow">
                    <Routes>
                      <Route path="/" element={<Home />} />
                      <Route path="/menu" element={<MenuPage />} />
                      <Route path="/order" element={<OrderPage />} />
                      <Route path="/reservation" element={<ReservationPage />} />
                      <Route path="/gallery" element={<GalleryPage />} />
                      <Route path="/about" element={
                        <div className="pt-32 pb-20 px-4 max-w-4xl mx-auto text-center">
                          <h1 className="text-5xl font-royal gold-text-gradient mb-8">Our Heritage</h1>
                          <p className="text-gray-300 text-lg leading-relaxed mb-12">
                            Founded in 1965, ADUPANGARAI was born from a desire to bring the royal dining experience of South Indian palaces to the modern connoisseur.
                          </p>
                        </div>
                      } />
                      <Route path="/contact" element={
                        <div className="pt-32 pb-20 px-4 max-w-7xl mx-auto">
                          <h1 className="text-4xl font-royal gold-text-gradient mb-6">Contact Us</h1>
                        </div>
                      } />
                    </Routes>
                  </main>
                  <Footer />
                </>
              } 
            />
          </Routes>
        </div>
      </Router>
    </CartProvider>
  );
};

export default App;
