
import { Category, MenuItem } from './types';

export const MENU_ITEMS: MenuItem[] = [
  // Veg Starters
  { id: 'v1', name: 'Gobi Manchurian', price: 180, category: Category.VEG_STARTERS, description: 'Crispy cauliflower tossed in tangy Indo-Chinese sauce.', isVeg: true, image: 'https://picsum.photos/400/300?random=1' },
  { id: 'v2', name: 'Paneer Tikka', price: 220, category: Category.VEG_STARTERS, description: 'Clay oven roasted cottage cheese with spices.', isVeg: true, image: 'https://picsum.photos/400/300?random=2' },
  { id: 'v3', name: 'Mushroom Pepper Fry', price: 200, category: Category.VEG_STARTERS, description: 'Classic South Indian mushroom fry with black pepper.', isVeg: true, image: 'https://picsum.photos/400/300?random=3' },
  
  // Non-Veg Starters
  { id: 'n1', name: 'Chicken 65', price: 240, category: Category.NON_VEG_STARTERS, description: 'Spicy deep-fried chicken - a classic Chennai specialty.', isVeg: false, image: 'https://picsum.photos/400/300?random=4' },
  { id: 'n2', name: 'Mutton Sukka', price: 320, category: Category.NON_VEG_STARTERS, description: 'Slow-cooked mutton with roasted spices and curry leaves.', isVeg: false, image: 'https://picsum.photos/400/300?random=5' },
  { id: 'n3', name: 'Fish Fry', price: 280, category: Category.NON_VEG_STARTERS, description: 'Tawa-fried fish seasoned with coastal spices.', isVeg: false, image: 'https://picsum.photos/400/300?random=6' },
  
  // Main Course Veg
  { id: 'mv1', name: 'Veg Meals', price: 180, category: Category.MAIN_COURSE_VEG, description: 'Complete traditional South Indian platter.', isVeg: true, image: 'https://picsum.photos/400/300?random=7' },
  { id: 'mv2', name: 'Paneer Butter Masala', price: 240, category: Category.MAIN_COURSE_VEG, description: 'Creamy tomato-based cottage cheese curry.', isVeg: true, image: 'https://picsum.photos/400/300?random=8' },
  { id: 'mv3', name: 'Mushroom Biryani', price: 220, category: Category.MAIN_COURSE_VEG, description: 'Aromatic basmati rice cooked with fresh mushrooms.', isVeg: true, image: 'https://picsum.photos/400/300?random=9' },
  
  // Main Course Non-Veg
  { id: 'mn1', name: 'Chicken Biryani', price: 250, category: Category.MAIN_COURSE_NON_VEG, description: 'Traditional Seeraga Samba rice chicken biryani.', isVeg: false, image: 'https://picsum.photos/400/300?random=10' },
  { id: 'mn2', name: 'Mutton Biryani', price: 340, category: Category.MAIN_COURSE_NON_VEG, description: 'Rich and authentic mutton biryani with aromatic spices.', isVeg: false, image: 'https://picsum.photos/400/300?random=11' },
  { id: 'mn3', name: 'Fish Curry Meals', price: 300, category: Category.MAIN_COURSE_NON_VEG, description: 'Tangy fish curry served with steamed rice and sides.', isVeg: false, image: 'https://picsum.photos/400/300?random=12' },
  
  // Tandoori
  { id: 't1', name: 'Tandoori Chicken', price: 320, category: Category.TANDOORI, description: 'Whole chicken marinated in yogurt and spices, grilled to perfection.', isVeg: false, image: 'https://picsum.photos/400/300?random=13' },
  { id: 't2', name: 'Butter Naan', price: 40, category: Category.TANDOORI, description: 'Soft, buttery leavened flatbread.', isVeg: true, image: 'https://picsum.photos/400/300?random=14' },
  
  // Desserts
  { id: 'd1', name: 'Gulab Jamun', price: 80, category: Category.DESSERTS, description: 'Deep-fried milk dumplings soaked in sugar syrup.', isVeg: true, image: 'https://picsum.photos/400/300?random=15' },
  { id: 'd2', name: 'Ice Cream', price: 90, category: Category.DESSERTS, description: 'Premium selection of artisanal ice creams.', isVeg: true, image: 'https://picsum.photos/400/300?random=16' },
  
  // Beverages
  { id: 'b1', name: 'Filter Coffee', price: 40, category: Category.BEVERAGES, description: 'Traditional South Indian frothy milk coffee.', isVeg: true, image: 'https://picsum.photos/400/300?random=17' },
  { id: 'b2', name: 'Fresh Lime Juice', price: 60, category: Category.BEVERAGES, description: 'Refreshing sweet and salt lime soda.', isVeg: true, image: 'https://picsum.photos/400/300?random=18' }
];

export const GALLERY_IMAGES = [
  { id: 'g1', url: 'https://picsum.photos/800/600?random=20', title: 'Royal Ambience' },
  { id: 'g2', url: 'https://picsum.photos/800/600?random=21', title: 'Exquisite Platter' },
  { id: 'g3', url: 'https://picsum.photos/800/600?random=22', title: 'Traditional Kitchen' },
  { id: 'g4', url: 'https://picsum.photos/800/600?random=23', title: 'Fine Dining Area' },
  { id: 'g5', url: 'https://picsum.photos/800/600?random=24', title: 'Signature Dish' },
  { id: 'g6', url: 'https://picsum.photos/800/600?random=25', title: 'Heritage Decor' }
];
